package Prepared_Statement_Class;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SELECT {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
			PreparedStatement ps=con.prepareStatement("select * from jbk");
			ResultSet rs=ps.executeQuery();
			
			System.out.println("******* SELECT TABLE **********");
			
			while(rs.next()) {
				System.out.println(rs.getInt(1) +" "+ rs.getString(2));
			}
			
		}catch(Exception e) {
			System.out.println(e);
		}

	}

}