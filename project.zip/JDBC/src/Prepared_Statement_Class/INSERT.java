package Prepared_Statement_Class;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class INSERT {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
			PreparedStatement ps=con.prepareStatement("insert into jbk (id,name) values(?,?)");
			
			ps.setInt(1, 101);
			ps.setString(2, "ABC");
			ps.executeUpdate();
			
			ps.setInt(1, 102);
			ps.setString(2, "DEF");
			ps.executeUpdate();
			
			ps.setInt(1, 103);
			ps.setString(2, "GHI");
			ps.executeUpdate();
			
			ps.setInt(1, 104);
			ps.setString(2, "JKL");
			ps.executeUpdate();
		}catch(Exception e) {
			System.out.println(e);
		}

	}

}

