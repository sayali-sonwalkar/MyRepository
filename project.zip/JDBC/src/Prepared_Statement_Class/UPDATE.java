package Prepared_Statement_Class;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class UPDATE {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
			PreparedStatement ps=con.prepareStatement("update jbk set name=? where id =?");
			
			ps.setString(1, "AAAA");
			ps.setInt(2, 101);
			ps.executeUpdate();
			
			System.out.println("********* UPDATE VALUE ********");
			
		}catch(Exception e) {
			System.out.println(e);
		}

	}

}