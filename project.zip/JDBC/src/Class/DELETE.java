package Class;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DELETE {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
			Statement s = con.createStatement();
			String query = "delete from student where name ='Kinjal'";
			s.executeUpdate(query);
			System.out.println("DELETE QUERY");
			
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
