package Class;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;

public class INSERT {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
			Statement s = con.createStatement();
			String query = "insert into student values(101,'Jyoti')";
			s.executeUpdate(query);
			System.out.println("INSERT QUERY");
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}