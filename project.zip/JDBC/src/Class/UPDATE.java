package Class;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class UPDATE {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
			Statement s =con.createStatement();
			String query1 = "update student set name='Kinjal' where id = 101 ";
			s.executeUpdate(query1);
			System.out.println("UPDATE QUERY");
			
		}catch(Exception e) {
			e.printStackTrace();	
		}	
	}

}
