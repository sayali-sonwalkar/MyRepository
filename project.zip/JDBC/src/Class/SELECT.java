package Class;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

public class SELECT {
	
		public static void main(String[] args) {
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
				Statement s = con.createStatement();
				String query="select * from student";
				ResultSet rs=s.executeQuery(query);
				while(rs.next()){
					System.out.println(rs.getInt(1)+"\t"+ rs.getString(2));
					}
				
				System.out.println("SELECT QUERY");
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
}

