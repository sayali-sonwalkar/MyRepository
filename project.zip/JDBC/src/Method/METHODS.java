package Method;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;

public class METHODS {
	public static void main(String[]args) {
		METHODS obj = new METHODS();
		//obj.insert();
		//obj.select();
		//obj.update();
		obj.delete();
	}

	public void insert() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
			Statement s = con.createStatement();
			String query = "insert into student values(101,'Jyoti')";
			s.executeUpdate(query);
			System.out.println("INSERT QUERY");
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void update() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
			Statement s =con.createStatement();
			String query1 = "update student set name='Kinjal' where id = 101";
			s.executeUpdate(query1);
			System.out.println("UPDATE QUERY");
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void delete(){
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
			Statement s = con.createStatement();
			String query = "delete from student where name ='Kinjal'";
			s.executeUpdate(query);
			System.out.println("DELETE QUERY");
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}	
	public void select() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
			Statement s = con.createStatement();
			String query="select * from student";
			ResultSet rs=s.executeQuery(query);
			while(rs.next()){
				System.out.println(rs.getInt(1)+"\t"+ rs.getString(2));
				}
			
			System.out.println("SELECT QUERY");
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
			
}
