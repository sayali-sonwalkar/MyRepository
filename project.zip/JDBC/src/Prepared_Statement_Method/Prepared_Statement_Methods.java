package Prepared_Statement_Method;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Prepared_Statement_Methods {

	public static void main(String[] args) throws Exception{
		Prepared_Statement_Methods ps= new Prepared_Statement_Methods();
		//ps.insert();
		//ps.update();
		//ps.delete();
		ps.select();
	}
	
	public void insert()throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
		PreparedStatement ps=con.prepareStatement("insert into jbk (id,name) values(?,?)");
		
		ps.setInt(1, 101);
		ps.setString(2, "ABC");
		ps.executeUpdate();
		
		ps.setInt(1, 102);
		ps.setString(2, "DEF");
		ps.executeUpdate();
		
		ps.setInt(1, 103);
		ps.setString(2, "GHI");
		ps.executeUpdate();
		
		ps.setInt(1, 104);
		ps.setString(2, "JKL");
		ps.executeUpdate();
	}
	public void update() throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
		PreparedStatement ps=con.prepareStatement("update jbk set name=? where id =?");
		
		ps.setString(1, "AAAA");
		ps.setInt(2, 101);
		ps.executeUpdate();
		
		System.out.println("********* UPDATE VALUE ********");
	}
	public void delete() throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
		PreparedStatement ps=con.prepareStatement("delete from jbk where id=?");
		
		ps.setInt(1, 102);
		ps.executeUpdate();
	
		System.out.println("********* DELETE VALUE ********");
		
	}
	public void select() throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","Welcome@12");
		PreparedStatement ps=con.prepareStatement("select * from jbk");
		ResultSet rs=ps.executeQuery();
		
		System.out.println("******* SELECT TABLE **********");
		
		while(rs.next()) {
			System.out.println(rs.getInt(1) +" "+ rs.getString(2));
		}
		
	}

}
